const socket = io()
const clientsTotal = document.querySelector('#clients-total')
const massegecontainer = document.querySelector('.message-container')
const nameInput = document.getElementById('name-input')
const massegeForm = document.getElementById('message-form')
const massegeInput = document.getElementById('message-input')
const sendMessageAudio = new Audio('/send.mp3')
massegeForm.addEventListener('submit',(e) => {
  e.preventDefault()
  sendMessage()
})
socket.on('client-total', (data) => {
   console.log(data)
   clientsTotal.innerText = `total clients : ${data}`
 })
function sendMessage() {
  if(massegeInput.value === '') return  
  const data = {
    name:nameInput.value,
    message: massegeInput.value,
    dateTime: new Date()
  }
  socket.emit('message',data)
  addMessageToUI(true , data)
}
socket.on('chat-message', (data) => {
  console.log(`Message from server: ${data.message}`)
  sendMessageAudio.play()
  addMessageToUI(false , data)
})
function addMessageToUI(isOwnMessage,data){
  clearFeedback()
  const element = `
         <li class="${isOwnMessage ? "message-right" : "message-left"} message-left">
                <p class="message">
                   ${data.message}
                </p>
              <span>${data.name} . ${data.dateTime}</span>
         </li>
                `
                massegecontainer.innerHTML += element
                massegeInput.value = ''
                scrollToBottom()
                

}
function scrollToBottom() {
  massegecontainer.scrollTo(0 , massegecontainer.scrollHeight)
}
massegeInput.addEventListener('focus', () => {
socket.emit('feedback', {
  feedback: `${nameInput.value} is typing`
})
})
massegeInput.addEventListener('keypress', () => {
  socket.emit('feedback', {
  feedback: `${nameInput.value} is typing`
})
})
massegeInput.addEventListener('blur', () => {
  socket.emit('feedback', {
  feedback: ``
})
})
socket.on('feedback', (data) => {
  clearFeedback()
  const element = `
                <li class="message-feedback" id="message-feedback">
                    <p class="feedback">
                       💬${data.feedback}
                    </p>
                </li>
                  `
                  massegecontainer.innerHTML += element
                  scrollToBottom()
})
function clearFeedback() {
  document.querySelectorAll('li.message-feedback').forEach(element => {
    element.parentNode.removeChild(element)
  })
}